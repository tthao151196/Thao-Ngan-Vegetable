import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, NavLink, Navigate } from "react-router-dom";
import "./index.css";

// ✅ import toast
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// ===== Customer pages =====
import Home from "./pages/Customers/Home";
import Products from "./pages/Customers/Products";
import Cart from "./pages/Customers/Cart";
import ProductDetail from "./pages/Customers/ProductDetail";
import CategoryProducts from "./pages/Customers/CategoryProducts";
import Register from "./pages/Customers/Register";
import Login from "./pages/Customers/Login";
import Checkout from "./pages/Customers/Checkout";
import OrderTracking from "./pages/Customers/OrderTracking";
import Blog from "./pages/Customers/Blog";
// ===== Admin pages/layout =====
import AdminLayout from "./layouts/AdminLayout";
import Dashboard from "./pages/Admin/Dashboard";
import AdminProducts from "./pages/Admin/Product/Products";
import AdminCategories from "./pages/Admin/Category/Categories";
import AdminOrders from "./pages/Admin/Order/Orders";
import AdminUsers from "./pages/Admin/User/Users";
import AddProduct from "./pages/Admin/Product/AddProduct";
import EditProduct from "./pages/Admin/Product/EditProduct";
import AddCategory from "./pages/Admin/Category/AddCategory";
import LoginAdmin from "./pages/Admin/LoginAdmin"; // ✅ thêm login admin
import AdminRoute from "./components/AdminRoute";   // ✅ bảo vệ route admin
import OrderDetail from "./pages/Admin/Order/OrderDetail"; 
import EditCategory from "./pages/Admin/Category/EditCategory"; // ✅ import

// ---- Hàm logout (gọi API + xoá localStorage) ----
const handleLogout = async () => {
  const token = localStorage.getItem("token");

  try {
    if (token) {
      const res = await fetch("http://127.0.0.1:8000/api/logout", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
      await res.json().catch(() => ({})); // ignore lỗi JSON
    }
  } catch (err) {
    console.error("Logout failed:", err);
  } finally {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    toast.info("👋 Bạn đã đăng xuất!");
    setTimeout(() => {
      window.location.href = "/login"; // chuyển về login customer
    }, 1200);
  }
};

// ---- Layout cho phần khách hàng ----
// function Layout({ children }) {
//   const user = JSON.parse(localStorage.getItem("user") || "null");

//   return (
//     <div className="min-h-screen flex flex-col">
//       <header className="px-4 py-3 border-b flex items-center justify-between">
//         <div className="font-semibold">🍃 StoreVegetables</div>
//         <nav className="flex gap-4 items-center">
//           <NavLink to="/" end>Trang chủ</NavLink>
//           <NavLink to="/products">Sản phẩm</NavLink>
//           <NavLink to="/cart">Giỏ hàng</NavLink>

//           {user ? (
//             <>
//               <span style={{ color: "green", fontWeight: 600 }}>
//                 👋 Xin chào, {user.name}
//               </span>
//               <button
//                 onClick={handleLogout}
//                 style={{
//                   marginLeft: 12,
//                   background: "#d32f2f",
//                   color: "#fff",
//                   border: 0,
//                   borderRadius: 8,
//                   padding: "6px 10px",
//                   cursor: "pointer",
//                 }}
//               >
//                 Đăng xuất
//               </button>
//             </>
//           ) : (
//             <>
//               <NavLink to="/register">Đăng ký</NavLink>
//               <NavLink to="/login">Đăng nhập</NavLink>
//             </>
//           )}
//         </nav>
//       </header>

//       <main className="flex-1 p-4">{children}</main>

//       <footer className="px-4 py-3 border-t text-sm text-gray-600">
//         © {new Date().getFullYear()} StoreVegetables
//       </footer>
//     </div>
//   );
// }
    // có gạch chân dưới link hiện tại
function Layout({ children }) {
  const user = JSON.parse(localStorage.getItem("user") || "null");

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-white to-emerald-50/40">
      <header className="px-4 py-3 border-b flex items-center justify-between sticky top-0 z-40 bg-white/80 backdrop-blur supports-[backdrop-filter]:bg-white/60 shadow-sm">
        <div className="font-semibold flex items-center gap-2 text-lg">
          🍃 <span className="tracking-tight">StoreVegetables</span>
        </div>

        <nav className="flex gap-2 md:gap-4 items-center">
          <NavLink to="/" end className="navlink">Trang chủ</NavLink>
          <NavLink to="/products" className="navlink">Sản phẩm</NavLink>
          <NavLink to="/cart" className="navlink">Giỏ hàng</NavLink>
          <NavLink to="/blog" className="navlink">Blog</NavLink>

          {user ? (
            <>
              <span style={{ color: "green", fontWeight: 600 }}>
                👋 Xin chào, {user.name}
              </span>
              <button
                onClick={handleLogout}
                style={{
                  marginLeft: 12,
                  background: "#d32f2f",
                  color: "#fff",
                  border: 0,
                  borderRadius: 8,
                  padding: "6px 10px",
                  cursor: "pointer",
                }}
              >
                Đăng xuất
              </button>
            </>
          ) : (
            <>
              <NavLink to="/register" className="navlink">Đăng ký</NavLink>
              <NavLink to="/login" className="navlink">Đăng nhập</NavLink>
            </>
          )}
        </nav>
      </header>

      <main className="flex-1 p-4 max-w-6xl mx-auto">{children}</main>

      <footer className="px-4 py-4 border-t text-sm text-gray-600 bg-white/70 backdrop-blur">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <span>© {new Date().getFullYear()} StoreVegetables</span>
          <span className="text-gray-500">Tươi mỗi ngày 🥬</span>
        </div>
      </footer>

      {/* Chỉ CSS giao diện, không đụng logic */}
      <style>{`
        :root { --e: cubic-bezier(.2,.8,.2,1); }

        /* Link cơ bản */
        .navlink{
          position:relative;
          padding:.5rem .75rem;
          border-radius:.75rem;
          font-weight:700;
          color:#0f766e;              /* teal-700 */
          transition: color .2s var(--e), background .2s var(--e), transform .2s var(--e);
        }
        .navlink:hover{
          color:#047857;              /* emerald-700 */
          background:rgba(16,185,129,.08);
          transform: translateY(-1px);
        }

        /* Active bằng aria-current (React Router v6 tự gán) */
        .navlink[aria-current="page"]{
          color:#047857;
        }
        .navlink[aria-current="page"]::after{
          content:"";
          position:absolute; left:12%; right:12%; bottom:-8px;
          height:3px; border-radius:9999px;
          background: linear-gradient(90deg,#00c853,#00e676);
        }
      `}</style>
    </div>
  );
}

function App() {
  // ✅ Lấy giỏ hàng từ localStorage khi khởi tạo
  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem("cart");
    return saved ? JSON.parse(saved) : [];
  });

  // ✅ Mỗi lần cart thay đổi thì lưu lại vào localStorage
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  // ✅ Hàm thêm sản phẩm
  const addToCart = (product) => {
    setCart((prev) => {
      const exists = prev.find((i) => i.id === product.id);
      return exists
        ? prev.map((i) =>
            i.id === product.id ? { ...i, qty: i.qty + 1 } : i
          )
        : [...prev, { ...product, qty: 1 }];
    });
    toast.success("🎉 Sản phẩm đã được thêm vào giỏ hàng!");
  };

  return (
    <BrowserRouter>
      <Routes>
        {/* ====== Customer routes ====== */}
        <Route path="/" element={<Layout><Home /></Layout>} />
        <Route path="/products" element={<Layout><Products addToCart={addToCart} /></Layout>} />
        <Route path="/category/:id" element={<Layout><CategoryProducts addToCart={addToCart} /></Layout>} />
        <Route path="/categories/:id" element={<Navigate to="/category/:id" replace />} />
        <Route path="/products/:id" element={<Layout><ProductDetail addToCart={addToCart} /></Layout>} />
        <Route path="/checkout" element={<Layout><Checkout cart={cart} setCart={setCart} /></Layout>} />
        <Route path="/cart" element={<Layout><Cart cart={cart} setCart={setCart} /></Layout>} />
        <Route path="/register" element={<Layout><Register /></Layout>} />
        <Route path="/login" element={<Layout><Login /></Layout>} />
        
<Route path="/track" element={<OrderTracking />} />
<Route path="/blog" element={<Blog />} />

        {/* ====== Admin login riêng ====== */}
        <Route path="/admin/login" element={<LoginAdmin />} />
        <Route path="/admin/orders/:id" element={<OrderDetail />} />

        {/* ====== Admin routes (protected) ====== */}
        <Route
          path="/admin"
          element={
            <AdminRoute>
              <AdminLayout />
            </AdminRoute>
          }
        >
          <Route index element={<Dashboard />} />   {/* ✅ /admin = Dashboard */}
          <Route path="products" element={<AdminProducts />} />
          <Route path="products/add" element={<AddProduct />} />
          <Route path="products/:id/edit" element={<EditProduct />} />
          <Route path="categories" element={<AdminCategories />} />
          <Route path="categories/add" element={<AddCategory />} />
          <Route path="orders" element={<AdminOrders />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="categories/edit/:id" element={<EditCategory />} />
        </Route>

        {/* 404 */}
        <Route path="*" element={<Layout><div>Không tìm thấy trang</div></Layout>} />
      </Routes>

      {/* ✅ Container cho thông báo */}
      <ToastContainer position="top-right" autoClose={2000} />
    </BrowserRouter>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
