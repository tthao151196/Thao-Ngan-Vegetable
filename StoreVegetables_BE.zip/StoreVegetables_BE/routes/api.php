<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\ReviewController;

// ===== Auth =====
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');

// ===== Products =====
Route::get('/products', [ProductController::class, 'index']);
Route::get('/products/{id}', [ProductController::class, 'show']);
Route::get('/categories/{id}/products', [ProductController::class, 'byCategory']);

// ===== Categories =====
Route::get('/categories', [CategoryController::class, 'index']);
Route::get('/categories/{id}', [CategoryController::class, 'show']);
Route::post('/categories', [CategoryController::class, 'store']);
Route::put('/categories/{id}', [CategoryController::class, 'update']);
Route::delete('/categories/{id}', [CategoryController::class, 'destroy']);

// ===== Orders (public xem danh sách, chi tiết) =====
Route::get('/orders', [OrderController::class, 'index']);
Route::get('/orders/{id}', [OrderController::class, 'show']);

// Checkout bắt buộc đăng nhập
Route::post('/checkout', [OrderController::class, 'checkout'])->middleware('auth:sanctum');

// ===== Users (Admin) =====
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/users', [UserController::class, 'index']);
    Route::get('/users/{id}', [UserController::class, 'show']);
    Route::post('/users', [UserController::class, 'store']);
    Route::put('/users/{id}', [UserController::class, 'update']);
    Route::delete('/users/{id}', [UserController::class, 'destroy']);
    Route::post('/users/{id}/lock', [UserController::class, 'lock']);
    Route::post('/users/{id}/unlock', [UserController::class, 'unlock']);
});

// ===== Admin (/api/admin/...) =====
Route::prefix('admin')->middleware('auth:sanctum')->group(function () {
    Route::get('/products', [ProductController::class, 'adminIndex']);
    Route::post('/products', [ProductController::class, 'store']);
    Route::put('/products/{id}', [ProductController::class, 'update']);
    Route::delete('/products/{id}', [ProductController::class, 'destroy']);

    // ✅ Thêm API đổi trạng thái đơn
    Route::put('/orders/{id}/status', [OrderController::class, 'updateStatus']);
});

// Reviews
Route::get('/products/{id}/reviews', [ReviewController::class, 'index'])->whereNumber('id');
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/products/{id}/can-review', [ReviewController::class, 'canReview'])->whereNumber('id');
    Route::post('/products/{id}/reviews',   [ReviewController::class, 'store'])->whereNumber('id');
    Route::put('/reviews/{id}',             [ReviewController::class, 'update'])->whereNumber('id');
    Route::delete('/reviews/{id}',          [ReviewController::class, 'destroy'])->whereNumber('id');
});
