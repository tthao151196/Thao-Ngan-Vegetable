<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Review;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ReviewController extends Controller
{
    /**
     * ✅ Danh sách review của 1 sản phẩm (public)
     */
    public function index($productId)
    {
        $reviews = Review::with('user:id,name')
            ->where('product_id', $productId)
            ->latest()
            ->get();

        return response()->json($reviews);
    }

    /**
     * ✅ Kiểm tra user có quyền review sản phẩm này không
     * Điều kiện: đã mua & đơn hàng ở trạng thái hoàn tất
     */
    public function canReview($productId)
    {
        $userId = Auth::id();
        if (!$userId) {
            return response()->json(['canReview' => false]);
        }

        // ⚠️ Nếu DB bạn đặt tên khác (vd: orderdetail, ptdt_orderdetail), hãy đổi lại cho đúng
        $hasPurchased = DB::table('order_items')
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.user_id', $userId)
            ->where(function ($q) {
                $q->where('orders.status', 1)
                  ->orWhere('orders.status', 'Completed');
            })
            ->where('order_items.product_id', $productId)
            ->exists();

        return response()->json(['canReview' => $hasPurchased]);
    }

    /**
     * ✅ Tạo hoặc cập nhật review
     * Chỉ cho phép nếu user đã mua sản phẩm và đơn đã hoàn tất
     */
    public function store(Request $request, $productId)
    {
        $userId = Auth::id();
        if (!$userId) {
            return response()->json(['error' => 'Chưa đăng nhập'], 401);
        }

        $data = $request->validate([
            'rating'  => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:1000',
        ]);

        // Kiểm tra user đã mua sp này chưa
        $hasPurchased = DB::table('order_items')
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.user_id', $userId)
            ->where(function ($q) {
                $q->where('orders.status', 1)
                  ->orWhere('orders.status', 'Completed');
            })
            ->where('order_items.product_id', $productId)
            ->exists();

        if (!$hasPurchased) {
            return response()->json([
                'error' => 'Bạn chưa mua sản phẩm này hoặc đơn chưa hoàn tất'
            ], 403);
        }

        // Upsert (mỗi user chỉ 1 review / sản phẩm)
        $review = Review::updateOrCreate(
            ['user_id' => $userId, 'product_id' => (int)$productId],
            [
                'rating'      => $data['rating'],
                'comment'     => $data['comment'] ?? null,
                'is_verified' => true,
            ]
        );

        $review->load('user:id,name');

        return response()->json($review, 201);
    }

    /**
     * ✅ Sửa review (chỉ chủ sở hữu mới được sửa)
     */
    public function update(Request $request, $id)
    {
        $review = Review::findOrFail($id);

        if ($review->user_id !== Auth::id()) {
            return response()->json(['error' => 'Không có quyền chỉnh sửa'], 403);
        }

        $data = $request->validate([
            'rating'  => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:1000',
        ]);

        $review->update($data);
        $review->load('user:id,name');

        return response()->json($review);
    }

    /**
     * ✅ Xóa review (chỉ chủ sở hữu mới được xóa)
     */
    public function destroy($id)
    {
        $review = Review::findOrFail($id);

        if ($review->user_id !== Auth::id()) {
            return response()->json(['error' => 'Không có quyền xóa'], 403);
        }

        $review->delete();

        return response()->json(['message' => 'Đã xóa review']);
    }
}
