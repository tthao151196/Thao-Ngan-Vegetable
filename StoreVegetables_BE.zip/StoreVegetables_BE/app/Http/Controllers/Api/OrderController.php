<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderDetail;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function checkout(Request $request)
    {
        $data = $request->validate([
            'customer_name'   => 'required|string|max:100',
            'phone'           => 'required|string|max:20',
            'address'         => 'required|string|max:255',
            'email'           => 'required|email|max:255',
            'items'           => 'required|array|min:1',
            'items.*.id'      => 'required|integer',   // product_id
            'items.*.name'    => 'required|string',
            'items.*.price'   => 'required|numeric',
            'items.*.qty'     => 'required|integer|min:1',
        ]);

        $total = collect($data['items'])->sum(fn ($i) => $i['price'] * $i['qty']);

        $order = Order::create([
            'name'     => $data['customer_name'],
            'phone'    => $data['phone'],
            'email'    => $data['email'],
            'address'  => $data['address'],
            'user_id'  => Auth::id() ?? null,
            'status'   => 0, // pending
            'note'     => "Tổng đơn: {$total} đ",
        ]);

        // Lưu chi tiết & gom ID để trả về
        $createdItems = [];
        foreach ($data['items'] as $item) {
            $detail = OrderDetail::create([
                'order_id'   => $order->id,
                'product_id' => $item['id'],
                'price_buy'  => $item['price'],
                'qty'        => $item['qty'],
                'amount'     => $item['price'] * $item['qty'],
            ]);

            $createdItems[] = [
                'order_detail_id' => $detail->id,
                'product_id'      => $detail->product_id,
                'price'           => (float) $detail->price_buy,
                'qty'             => (int) $detail->qty,
                'subtotal'        => (float) $detail->amount,
            ];
        }

        return response()->json([
            'message'   => 'Đặt hàng thành công',
            'id'        => $order->id,      // 👈 thêm id trực tiếp
            'order_id'  => $order->id,      // giữ backward-compat nếu FE đang dùng
            'user_id'   => $order->user_id,
            'total'     => (float) $total,
            'status'    => (int) $order->status,
            'items'     => $createdItems,   // 👈 trả về id của từng dòng chi tiết + product_id
        ]);
    }

    public function index(Request $request)
    {
        $status   = $request->integer('status', null);
        $search   = (string) $request->get('search', '');
        $perPage  = max(1, min(100, (int) $request->get('per_page', 20)));

        $q = Order::query()
            ->withCount('details')                   // details_count
            ->withSum('details as total', 'amount'); // tổng tiền từ order_details.amount

        if (!is_null($status)) {
            $q->where('status', $status);
        }

        if ($search !== '') {
            $q->where(function ($qq) use ($search) {
                $qq->where('name', 'like', "%{$search}%")
                   ->orWhere('phone', 'like', "%{$search}%")
                   ->orWhere('email', 'like', "%{$search}%")
                   ->orWhere('id', $search);
            });
        }

        // Paginator sẽ trả về id sẵn có,
        // ở đây chuẩn hoá thêm field status_int cho FE dùng tiện
        $orders = $q->latest('id')->paginate($perPage)->through(function ($o) {
            return [
                'id'            => $o->id,
                'name'          => $o->name,
                'email'         => $o->email,
                'phone'         => $o->phone,
                'address'       => $o->address,
                'status'        => $o->status,
                'status_int'    => (int) $o->status,
                'details_count' => $o->details_count,
                'total'         => (float) ($o->total ?? 0),
                'created_at'    => $o->created_at,
                'updated_at'    => $o->updated_at,
            ];
        });

        return response()->json($orders);
    }

    public function show($id)
    {
        $order = Order::with(['details.product'])->findOrFail($id);

        $total = $order->details->sum(fn ($d) => $d->amount ?? $d->price_buy * $d->qty);

        return response()->json([
            'id'         => $order->id,                 // 👈 id đơn
            'user_id'    => $order->user_id,            // 👈 user id (nếu có)
            'name'       => $order->name,
            'email'      => $order->email,
            'phone'      => $order->phone,
            'address'    => $order->address,
            'note'       => $order->note,
            'status'     => (int) ($order->status ?? 0),
            'total'      => (float) $total,
            'created_at' => $order->created_at,
            'updated_at' => $order->updated_at,
            'items'      => $order->details->map(function ($d) {
                $p = $d->product;
                return [
                    'order_detail_id' => $d->id,                // 👈 id dòng chi tiết (rõ ràng)
                    'product_id'      => $d->product_id,        // 👈 dùng để dẫn sang trang review
                    'product_name'    => $p?->name ?? 'Sản phẩm đã xoá',
                    'product_image'   => $p?->thumbnail_url ?? $p?->thumbnail ?? null,
                    'price'           => (float) $d->price_buy,
                    'qty'             => (int) $d->qty,
                    'subtotal'        => (float) ($d->amount ?? $d->price_buy * $d->qty),
                ];
            })->values(),
        ]);
    }
    public function updateStatus(Request $request, $id)
{
    $data = $request->validate([
        'status' => 'required|in:0,1,2' // 0=pending,1=completed,2=cancelled
    ]);

    $order = Order::findOrFail($id);
    $order->status = (int) $data['status'];
    if (auth()->check()) {
        $order->updated_by = auth()->id();
    }
    $order->save();

    return response()->json([
        'message' => 'Updated',
        'order'   => [
            'id'      => $order->id,
            'status'  => (int) $order->status,
            'updated' => $order->updated_at,
        ],
    ]);
}

}
